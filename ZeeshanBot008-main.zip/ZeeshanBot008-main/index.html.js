</html>

<html>

<head>    


<title>Zeeshan Altaf</title>



</head>



  <body bgcolor="black" >

  <font color="red"> <h3> <marquee> Welcome to Zeeshan BOT-008  </marquee> </h3> </font>
  



 <font color="white">   <p> THIS BOT IS UNDER PROTECTED BY </p> <p> Zeeshan Altaf </p>
  <p> Contact my facebook account for approval </P>
  <p> https://www.facebook.com/zeeshanaltafofficial01 </p>  </font>



   <font color="pink"> <a href="https://www.facebook.com/zeeshanfofficial01"> <font color="yellow"> Contact </font> </a> 



<div style="height: 373.33px; width: 300.00px; position:relative;"><iframe allow="autoplay; gyroscope;" allowfullscreen height="100%" referrerpolicy="strict-origin" src="https://www.kapwing.com/e/63d96b66088199001e831581" style="border:0; height:100%; left:0; overflow:hidden; position:absolute; top:0; width:100%" title="Embedded content made on Kapwing" width="100%"></iframe></div><p style="font-size: 12px; text-align: right;">Video edited on <a href="https://www.kapwing.com/video-editor">Kapwing</a></p>



   <a href="https://ibb.co/Sd9PLB4"><img src="https://i.ibb.co/Sd9PLB4/Picsart-23-02-01-00-11-17-278.jpg" alt="Picsart-23-02-01-00-11-17-278" border="0"></a>













    
  
  </body>

  
  
  

  
</html>


