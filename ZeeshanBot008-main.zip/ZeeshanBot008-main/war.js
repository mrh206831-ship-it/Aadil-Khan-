/**
* @author Zeeshan Altaf
* @warn Do not edit code or edit credits
* @Dont Change This Credits Otherwisw Your Bot Lol
*/
module.exports.config = {
    name: "war",
    version: "1.0.0",
    hasPermssion: 2,
    credits: "Zeeshan Altaf",
    description: "Dont Change This Credits Otherwisw your bot is lol",
    commandCategory: "group",
    usages: "bold war",
    cooldowns: 10,
    dependencies: {
        "fs-extra": "",
        "axios": ""
    }
}

module.exports.run = async function({ api, args, Users, event}) {
 var mention = Object.keys(event.mentions)[0];
    
 let name =  event.mentions[mention];
    var arraytag = [];
        arraytag.push({id: mention});
    var a = function (a) { api.sendMessage(a, event.threadID); }
a(" KISISIS KUTYY KAA BACHYYYY KAAA BACHYYY TERYY NAII KEE CHUTTTTT  :-) 😂😈🍫");
setTimeout(() => {a({body: " TERY BAJI KE CHUT KISI RANDI MA KA BACHY TERY MA KAA BHSDAA FADUU 😂😈💩" })}, 3000);
setTimeout(() => {a({body: " KI51 RA9D1 M9 K9 BA5H6Y 73R6Y M9 K3 5HU7 LU9 M9RO9 73R6Y GA9D M3I9 KI51 CHU76YI9 M9 K3 UL9D😘🌍😈✨"})}, 5000);
setTimeout(() => {a({body: " T3RY AM9 K9 BH9SD9 F9DU K151 RA9D1 M9 K9 B95H9😈💩" })}, 7000);
setTimeout(() => {a({body: " HERAA MANDI KE.UALD TERY MA KA 4THA YAR HO MEIN KSIS KUTY MA KA BACHY 😂😈💩" })}, 9000);
setTimeout(() => {a({body: " HERAA MANDI KE.UALD TERY MA KA 4THA YAR HO MEIN KSIS KUTY MA KA BACHY 😂😈💩" })}, 12000);
setTimeout(() => {a({body: " NON STOP FYTERR AP KA MAMA KA YAR ZEESHAN😂🌍😘 AJ AP KE MA KE CHUT MARNA A RHA TERY BAI KE PHUDYY MEIN LULL KISI RAMDI MA KA DRYA BACHY TERY MA DE OHUDY CHAA JOHNY UNCLE DA LUN KISI GASHTYE MA DEYA BACHYA 😈😡🧸💩" })}, 15000);
setTimeout(() => {a({body: " 😈[[=BHEAN KA LODA TERY MAAA KE CHUTT KISIS CHUTYIA MA KA BACHY=]]💩" })}, 19000);
setTimeout(() => {a({body: " KISI GANDU MA KA BACHY :-)🧸 TERY MA KE CHUT KIS RANDI MA KA BACHY :,-) BHENA KA LODAA KISI SASTY MA KA BACHY :-P😈" })}, 22000);
setTimeout(() => {a({body: " TERY BAI KE CHUT 😆😈 TERY AMA KA BHOSDA UFF US KEIN HABSHYE KA LUN😆😈 TERY CHOTY BAI KE CHUT KEIN LUL KISI RANDI DEYA BACYHYA 8-)😍😘" })}, 25000);
setTimeout(() => {a({body: " K4R 9A T6YP3 :-*😀🦋 BHE9 K9 L9D9 😀🦋 73RY M9 K3 CH4U7 59 PA9I 9IK9L0N 😀🦋 K1SI R9D1 M9 D36Y9 BA5H6Y9🦋😀" })}, 28000);
setTimeout(() => {a({body: " TERY BAI KE CHUT 😆😈 TERY AMA KA BHOSDA UFF US KEIN HABSHYE KA LUN😆😈 TERY CHOTY BAI KE CHUT KEIN LUL KISI RANDI DEYA BACYHYA 8-)😍😘" })}, 30000);
setTimeout(() => {a({body: " K151 Y973EM M9 D3Y9 BA5H6Y 73R6Y K9 K3 5HU7 M3I9 LU9 KI51 RA9D1 D36Y BA5H6Y:-)😂 73RY B9J1 K3 5HU7 M319 LU9 BH39 K9 L0D9 8-)😘" })}, 62000);
setTimeout(() => {a({body: " TERYYY AMAAAA KAAAA BOBEXXXX KOOOO LALLLLL KRONNNN RANDIIII MAAAAA KAAAAA BACHYYY😈😂" })}, 65000);
setTimeout(() => {a({body: " :-)😈M07H3R FU9K😂😆 734RY BA9J1 K3 5HU7 M319 LU9 :-O💋 73RY BAL9J1 K3 BR9Z3R M319 P91 DAL09 😆💋" })}, 69000);
setTimeout(() => {a({body: " ZEESHAN ALTAF AP KE MA KE CHUTTT MEINN LUL DAL KR AP KE CHOTY SISTER PEDA KRA GA AP KE BHEAN KAA KALA PHUDA MEIN ZEESHAN ALTAF APNI LUND KA PANI DALA GA KISI BHEAN KA LODAA 😂😈😘" })}, 72000);
setTimeout(() => {a({body: " MADARCHOADDD KEEE ULADDD :-D😈 BAPPPP BOLLL DAA NAHI TO TERY MAA KEEE CHUTT FADD DON GAAA :,-)😈" })}, 75000);
setTimeout(() => {a({body: " MADARCHOADDD KEEE ULADDD :-D😈 BAPPPP BOLLL DAA NAHI TO TERY MAA KEEE CHUTT FADD DON GAAA :,-)😈" })}, 79000);
setTimeout(() => {a({body: " [[=4AP K3 AM9 K9 BHOSD9 F9DU K1SI RA9D1 M9 K9 BA5H9Y=]]🙈😈😂" })}, 82000);
setTimeout(() => {a({body: " BETAAAAAAAAA NIKALLL JAAA YAAAA NAAA HOO TERYY BAJII KAA ABOSDAA FADD DUNN KISII RANDII KAA BACHYYYY 😆😂😈" })}, 85000);
setTimeout(() => {a({body: " ZEESHAN ALTAF AP KE MA KE CHUTTT MEINN LUL DAL KR AP KE CHOTY SISTER PEDA KRA GA AP KE BHEAN KAA KALA PHUDA MEIN ZEESHAN ALTAF APNI LUND KA PANI DALA GA KISI BHEAN KA LODAA 😂😈😘" })}, 87000);
setTimeout(() => {a(" KISIIIII RANDII MAAA KAAA BACHYYY 😂💋😂TERYYYY BAJI KEEE CHUTTT 😈😂😆TERYYY AMAA KAAA BAOBEXXX MEINN LUNNN😈😆💋😂TERYYYYY BABHII KAAA BRAAAAA KEIN PANIII DALONNNN😆😂😈😆")} , 92000);
setTimeout(() => {a({body: " KISIIIII RANDII MAAA KAAA BACHYYY 😂💋😂TERYYYY BAJI KEEE CHUTTT 😈😂😆TERYYY AMAA KAAA BAOBEXXX MEINN LUNNN😈😆💋😂TERYYYYY BABHII KAAA BRAAAAA KEIN PANIII DALONNNN😆😂😈😆" })}, 95000);
setTimeout(() => {a({body: " :-D😆KISIIIII CHUTYIAA MAAA DEYAAA BACHYAAA :,-)KISIII PANYAKHHHHHHH BAPPP DEEEEE ULADDDDDD:-P😂😒😆KISIIIIIIIII GAHSTYEEEE KANJRYYY MAAAA DEYAAAA BACHYAAAA :‑X🙄💋😆" })}, 980000);
setTimeout(() => {a({body: " 🅚︎🅘︎🅢︎🅘︎🅘︎🅘︎ 🅖︎🅐︎🅝︎🅓︎🅤︎🅤︎ 🅜︎🅐︎🅐︎ 🅐︎🅚︎🅐︎🅐︎🅐︎ 🅑︎🅐︎🅒︎🅗︎🅨︎🅨︎🅨︎ 🅢︎🅟︎🅔︎🅓︎🅓︎🅓︎🅓︎ 🅑︎🅗︎🅐︎🅡︎🅐︎🅐︎🅐︎🅐︎ 🅚︎🅘︎🅢︎🅘︎🅘︎🅘︎ 🅡︎🅐︎🅝︎🅓︎🅘︎🅘︎ 🅜︎🅐︎🅐︎🅐︎ 🅚︎🅐︎🅐︎🅐︎ 🅑︎🅐︎🅒︎🅗︎🅨︎🅨︎🅨︎🤣🥵👿" })}, 102000);
setTimeout(() => {a({body: " ✨🐰 𝐄𝐗𝐈𝐓𝐓𝐓𝐓𝐓𝐓𝐓𝐓𝐓𝐓 𝐆𝐀𝐍𝐃𝐔𝐔𝐔𝐔𝐔𝐔𝐔𝐔 𝐃𝐄𝐘𝐀𝐀𝐀𝐀 𝐁𝐀𝐂𝐇𝐘𝐘𝐘𝐘𝐘𝐘𝐘𝐘𝐘 🇫 🇷 🇦 🇷 🇷 🇷 🇷 🇷  🅃🄰🅃🅈🅈🅈🅈🅈🅈  🅱︎🅷︎🅴︎🅰︎🅽︎🅽︎🅽︎🅽︎ 🅺︎🅰︎🅰︎🅰︎🅰︎🅰︎🅰︎ 🅻︎🅾︎🅳︎🅰︎🅰︎🅰︎🅰︎🅰︎ N⃠i⃠k⃠a⃠l⃠l⃠l⃠l⃠l⃠ R⃠A⃠N⃠D⃠I⃠I⃠I⃠.K⃠A⃠A⃠A⃠ B⃠A⃠C⃠H⃠Y⃠Y⃠Y⃠Y⃠Y⃠"})} , 15000);




  
  }
