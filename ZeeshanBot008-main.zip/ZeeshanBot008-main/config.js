{
    "language": "en",
    "keyActive": "",
    "DeveloperMode": false,
    "autoCreateDB": true,
    "allowInbox": true,
    "autoClean": false,
    "adminOnly": false,
    "keyAdminOnly": "",
    "commandDisabled": [
        "",
        "",
        "",
        "",
        ""
    ],
    "eventDisabled": [],
    "BOTOWNER": "Zeeshan Altag",
    "OWNERLINK": "https://www.facebook.com/profile.php?id=zeeshanofficial01",
    "OWNERID": "100009593303125",
    "BOTCREATOR": "Zeeshan Altaf",
    "CREATORLINK": "https://www.facebook.com/profile.php?id=zeeshanofficial01",
    "CREATORID": "100009593303125",
    "BOTNAME": "𝐋𝐄𝐀𝐑𝐍 𝐅𝐎𝐑 𝐁𝐄𝐆𝐈𝐍𝐍𝐄𝐑𝐒",
    "PREFIX": ".",
    "ADMINBOT": [
        "100009593303125",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        ""
    ],
    "Wibu_API": "iyEro7YK",
    "DATABASE": {
        "sqlite": {
            "storage": "data.sqlite"
        }
    },
    "APPSTATEPATH": "appstate.json",
    "FCAOption": {
        "forceLogin": true,
        "listenEvents": true,
        "pauseLog": true,
        "logLevel": "error",
        "selfListen": false,
        "userAgent": "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36 OPR/84.0.4316.21"
    },
    "version": "1.2.14",
    "help": {
        "autoUnsend": "",
        "delayUnsend": 60
    },
    "adminUpdate": {
        "autoUnsend": true,
        "sendNoti": true,
        "timeToUnsend": 10
    },
    "log": {
        "enable": true
    },
    "rankup": {
        "autoUnsend": "",
        "unsendMessageAfter": 5
    },
    "work": {
        "cooldownTime": 1200000
    },
    "youtube-video": {
        "YOUTUBE_API": "AIzaSyAV1Ob0n_87tZSmCMorTGE-jHVrAvnXcIM"
    },
    "linkword": {
        "APIKEY": ""
    },
    "ytb-video": {
        "YOUTUBE_API": "AIzaSyAV1Ob0n_87tZSmCMorTGE-jHVrAvnXcIM"
    },
    "math": {
        "WOLFRAM": "T8J8YV-H265UQ762K"
    },
    "luật bot": {
        "autoUnsend": true,
        "delayUnsend": 30
    },
    "lbot": {
        "autoUnsend": true,
        "delayUnsend": 30
    },
    "work-beta": {
        "cooldownTime": 1200000
    },
    "job-beta": {
        "cooldownTime": 5000
    },
    "job": {
        "cooldownTime": 5000
    },
    "sauce": {
        "SAUCENAO_API": "a2430f4a078a4782540142bfad2551f3384bd20f"
    },
    "weather": {
        "OPEN_WEATHER": "b7f1db5959a1f5b2a079912b03f0cd96"
    },
    "simsimi": {
        "APIKEY": "Meew_Ov8SwxqVjUMUJafvxWAsdeac7YAUnr"
    },
    "sim": {
        "APIKEY": "Meew_Ov8SwxqVjUMUJafvxWAsdeac7YAUnr"
    },
    "slap": {
        "APIKEY": "Meew_Ov8SwxqVjUMUJafvxWAsdeac7YAUnr"
    },
    "daily": {
        "cooldownTime": 43200000,
        "rewardCoin": 1000000000000000000
    },
    "manslap": {
        "APIKEY": "Meew_Ov8SwxqVjUMUJafvxWAsdeac7YAUnr"
    },
    "play": {
        "YOUTUBE_API": "AIzaSyBtiD442srhczDpcg8xbhinP423BeUFXB8",
        "SOUNDCLOUD_API": "M4TSyS6eV0AcMynXkA3qQASGcOFQTWub"
    },
    "video": {
        "YOUTUBE_API": "AIzaSyBtiD442srhczDpcg8xbhinP423BeUFXB8"
    },
    "testcovid": {
        "APIKEY": "Meew_kB5wRAlpHhrAj0GhRzmmLHesvvTbXE"
    },
    "fish": {
        "cooldownTime": 1000000
    },
    "simv2": {
        "APIKEY": "mzkVip_Simsimi"
    },
    "cave": {
        "cooldownTime": 1000000
    },
    "simvoice": {
        "APIKEY": "Meew_hTrAe8Ipec8EsSRsQXoMO7v0XaPgY0"
    },
    "sing": {
        "YOUTUBE_API": "AIzaSyBtiD442srhczDpcg8xbhinP423BeUFXB8",
        "SOUNDCLOUD_API": "M4TSyS6eV0AcMynXkA3qQASGcOFQTWub"
    },
    "slapv2": {
        "APIKEY": ""
    },
    "videov2": {
        "YOUTUBE_API": "AIzaSyDEE1-zZSRVI8lTaQOVsIAQFgL-_BJKvhk"
    },
    "help2": {
        "autoUnsend": true,
        "delayUnsend": 300
    },
    "sim2": {
        "APIKEY": "Meew_xVZVZ6g5i7Zz0TJyhTkDueNKlaoiOR"
    },
    "bannerbw": {
        "APIKEY": "ntkhang"
    },
    "caesar": {
        "caeserPassword": "266303"
    },
    "diemdanh": {
        "cooldownTime": 3000000
    },
    "hitbutt": {
        "APIKEY": ""
    },
    "hunter": {
        "userToken": "D7tTFhgD",
        "adminToken": "ZkSy3UsT"
    },
    "img": {
        "APIKEY": ""
    },
    "pokemon": {
        "APIKEY": ""
    },
    "rname": {
        "APIKEY": "mi451266190"
    },
    "sing1": {
        "API_KEY": "KeyTest_3Days"
    },
    "sortword": {
        "APIKEY": ""
    },
    "soundcloud": {
        "SOUNDCLOUD_API": "2uVsdjJYhZBsWRcsjxJPynPAgR1zE9OKJhKxydA41abYJfx08J"
    },
    "surprise": {
        "log": true,
        "out": "",
        "kickAll": "",
        "delThread": ""
    },
    "tiktoksearch": {
        "key": "DuI7QIGh"
    },
    "ytbmp4": {
        "YOUTUBE_API": "AIzaSyDEE1-zZSRVI8lTaQOVsIAQFgL-_BJKvhk"
    },
    "sing2": {
        "YOUTUBE_API": "AIzaSyC4iLJTqxpkRvDYSUnDHkUVAj0H4q5f3GE"
    },
    "tiktok": {
        "API_KEY": "mzkFree_722124509AC10"
    }
}