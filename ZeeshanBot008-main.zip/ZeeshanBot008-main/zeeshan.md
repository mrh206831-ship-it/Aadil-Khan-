## this bot is protected by zeeshan Altaf
## 🌸 How to use zeeshan Altaf bot 
_____("must follow given steps")
 ## __________STEPS___________
 ## 1.crete account on (replit.com)
 ## 2. contact me (or) search my bot name (LEARN FOR BEGINNERS) on replit search box find my bot and fork repl 
 ## 3. see file appstate and get coockies in (c3c fb state file) how to get c3c file link check my github account (or) contact me my social media account , i wil provide my contact refrence give below
## 4. coockies copy and paste for appstate.json
## 5. then mid of (run button) so tab for run button so your consel is start 
## 6. find config.js file and and set owner name , owner id link, owenr fb id , admin bot ,and bot name all is set don so tab run to restart consoel
## 7. dont change any coding otherwise i am not responsible for any risk 🥺
## 8. how to make Facebook messenger chat bot (use my tips and tricks ), for subscribe my YouTube channel and follow my Facebook page link give below👇
youtube link :- https://youtube.com/@zeeshanaltaftricks184
## YouTube Channel Name (Zeeshan Altaf Tricks) i have upload comepelte coure for bot related so you can free watch my all videos for techincal help and educational purposes 
      🤟HOW TO MAKE YOU ON PERSONAL BOT🍫
##        [I WILL UPLOAD COMPELET COURSE ABOUT BOT ]
##         [SEE MY YOUTUBE CHANNEL ]
            😍{HOW TO INSTALL COMPELET PAKGE FOR REPLIT}🤗
            
 ## [I WILL UPLOAD COMPELET RELIT INSTALATION PROCESS COMING SOON INSHALLAH ❤️]

 ___________ABOUT MY SELF___________

  MY NAME IS ZEESHAN ALTAF, I AM PHYSIOTHERAPIST AND CONTINUE STUDIES IN MY RELATED FIELD , NOW I AM STARTING JOB I AM TOTALY BUSY PERSON MY JOB WORK HOURS 11:00 AM TO 8:00 PM , I LIVE IN ISLAMABAD (RAWALPINDI ) I AM STARTED YOUTUBE CHANNEL FOR YOUGNER HELP LIKE ALL SOCIAL MEDIA TIPS AND TRICKS MY COURSES ARE FREE OF COST ❤️ CONTACT ME ON WHATSAPP FOR ANY AND FOLLOW MY SOCIAL MEDIA ACCOUNTS 
  _____________🤟🍫😍_____________

## CONTACT ME SOCIAL MEDIA ACCOUNTS
##  YOUTUBE LINK [https://youtube.com/@zeeshanaltaftricks184]❤️
##  FACEBOOK ID LINK [https://www.facebook.com/zeeshanofficial01?mibextid=ZbWKwL]🍫
##  FACEBOOK PAGE LINK [https://www.facebook.com/profile.php?id=100084918883783&mibextid=ZbWKwL]😍
##  INSTAGRAM ACCOUNT LINK [https://www.instagram.com/zeeshanaltafofficial]🥰
##  GITHUB ACCOUNT LINK [https://github.com/zeeshanqureshi0/zeeshanqureshi0]😘
##  WHATSAPP GROUP LINK [https://chat.whatsapp.com/BTHDVyQo0MeF4embI9IDl8]💖
##  BLOG WEBSITE LINK [https://zeeshanaltaftricks.blogspot.com/]🤟

## __________NOTE___________
DONTE FLLOW ME I AM NOT RESPONSIBLE FOR ANY LOSS 
DONT COPY PASTE MY CODE I HAVE NOT RESPONSIBLE FOR YOUR ANY LOSSS
THIS BOT IS USE FOR EDUCATIONAL PURPOSE 🥰

